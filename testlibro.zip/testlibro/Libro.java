/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testlibro;

import java.util.Objects;

/**
 *
 * @author utente
 */
public class Libro {
    

    // ATTRIBUTI PRIVATI
    private String titolo;
    private int numeroPagine;
    private int paginaCorrente;
    private double prezzo;
    private boolean aperto;

    /**
     * Costruttore della classe libro.
     *
     * @param titolo Il titolo del libro.
     * @param numeroPagine Il numero totale di pagine (deve essere > 0).
     * @param prezzo Il prezzo di copertina in Euro.
     */
    public Libro(String titolo, int numeroPagine, double prezzo) {
        this.titolo = titolo;
        this.numeroPagine = Math.max(1, numeroPagine);
        this.prezzo = Math.max(0.0, prezzo);
        this.paginaCorrente = 0;
        this.aperto = false;
    }

    // GET e SET

    public String getTitolo() {
        return titolo;
    }

    public int getNumeroPagine() {
        return numeroPagine;
    }

    public int getPaginaCorrente() {
        return paginaCorrente;
    }

    public double getPrezzo() {
        return prezzo;
    }

    public boolean isAperto() {
        return aperto;
    }

    public void setPrezzo(double nuovoPrezzo) {
        if (nuovoPrezzo >= 0) {
            this.prezzo = nuovoPrezzo;
        }
    }

    // METODI 

    /**
     * Apre il libro.
     * 
     * @return true se il Libro è stato aperto, false se era già aperto.
     */
    public boolean apri() {
        if (!aperto) {
            aperto = true;
            if (paginaCorrente == 0) {
                paginaCorrente = 1;
            }
            return true;
        }
        return false;
    }

    /**
     * Chiude il libro.
     * 
     * @return true se il Libro è stato chiuso, false se era già chiuso.
     */
    public boolean chiudi() {
        if (aperto) {
            aperto = false;
            return true;
        }
        return false;
    }

    /**
     * Sfoglia il libro avanti di una pagina.
     * 
     * @return true se ha avanzato di pagina, false altrimenti.
     */
    public boolean paginaSuccessiva() {
        if (aperto && paginaCorrente < numeroPagine) {
            paginaCorrente++;
            return true;
        }
        return false;
    }

    /**
     * Sfoglia il libro indietro di una pagina.
     * 
     * @return true se è tornato indietro di una pagina, false altrimenti.
     */
    public boolean paginaPrecedente() {
        if (aperto && paginaCorrente > 1) {
            paginaCorrente--;
            return true;
        }
        return false;
    }

    /**
     * Va ad una pagina specifica a scelta.
     * 
     * @param pagina Numero della pagina da raggiungere.
     * @return true se la pagina è stata raggiunta, false altrimenti.
     */
    public boolean vaiAllaPagina(int pagina) {
        if (aperto && pagina >= 1 && pagina <= numeroPagine) {
            paginaCorrente = pagina;
            return true;
        }
        return false;
    }

    /**
     * Applica uno sconto percentuale sul prezzo del libro.
     * 
     * @param percentuale Percentuale di sconto 
     * @return true se lo sconto è stato applicato, false se la percentuale non è valida.
     */
    public boolean applicaSconto(double percentuale) {
        if (percentuale > 0 && percentuale <= 100) {
            double sconto = (prezzo * percentuale) / 100.0;
            prezzo -= sconto;
            return true;
        }
        return false;
    }

 

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Libro altro = (Libro) obj;
        return numeroPagine == altro.numeroPagine && Objects.equals(titolo, altro.titolo);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.titolo);
        hash = 67 * hash + this.numeroPagine;
        return hash;
    }

    @Override
    public String toString() {
        return "Libro: " + titolo + " | Pagine: " + numeroPagine + " | Pagina Corrente: " + paginaCorrente + " | Prezzo: " + prezzo + " euro | Stato: " + (aperto ? "Aperto" : "Chiuso");
    }
}
        
        
        




