/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testlibro;

/**
 *
 * @author utente
 */
public class TestLibro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      
        // Istanziazione oggetti
        Libro l1 = new Libro("Ti prendo e ti porto via", 320, 15.00);
        Libro l2 = new Libro("Ti prendo e ti porto via", 320, 12.00);

        System.out.println("\nStato iniziale del libro:");
        System.out.println(l1);

        // Test a Libro chiuso
        System.out.println("\nTentativo di sfogliare a libro chiuso:");
        if (!l1.paginaSuccessiva()) {
            System.out.println("Errore: Impossibile sfogliare, il libro e chiuso.");
        }

        // Apertura del Libro
        System.out.println("\nApertura libro:");
        if (l1.apri()) {
            System.out.println("Hai aperto il libro: \"" + l1.getTitolo() + "\"");
        }

        //Sfoglio delle pagine
        System.out.println("\nSfoglio pagine:");
        if (l1.paginaSuccessiva()) {
            System.out.println("Sfogliato avanti -> Ora sei a pagina: " + l1.getPaginaCorrente());
        }

        if (l1.vaiAllaPagina(150)) {
            System.out.println("Salto effettuato -> Ora sei a pagina: " + l1.getPaginaCorrente());
        } else {
            System.out.println("Errore: Pagina non valida o libro chiuso.");
        }

        // Applicazione sconto
        System.out.println("\nApplicazione dello sconto:");
        double sconto = 20.0;
        if (l1.applicaSconto(sconto)) {
            System.out.println("Sconto del " + sconto + "% applicato con successo");
            System.out.println("Nuovo prezzo: " + l1.getPrezzo() + "euro");
        } else {
            System.out.println("Errore: Percentuale di sconto non valida.");
        }

        // Confronto tra libri
        System.out.println("\nConfronto tra libri:");
        if (l1.equals(l2)) {
            System.out.println("I due libri sono uguali.");
        } else {
            System.out.println("I due libri sono diversi.");
        }

        System.out.println("\nChiusura libro:");
        if (l1.chiudi()) {
            System.out.println("Hai chiuso il libro: \"" + l1.getTitolo() + "\"");
        }
        System.out.println(l1);
    }
}